
import sys
sys.path.append('/Users/Aida/Downloads/pyke3-1.1.1/pyke-1.1.1/examples/family_relations')
import driver

driver.fc_test('m_thomas')