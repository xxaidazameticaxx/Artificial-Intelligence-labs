

import sys
from pyke import knowledge_engine, krb_traceback
    
engine = knowledge_engine.engine(__file__)

def weather_test():
    engine.reset()
    engine.activate('weather_rules')
    try:
        with engine.prove_goal('weather_rules.what_to_bring($bring)') as gen:
            for vars, plan in gen:
                print("You should bring: %s" % (vars['bring']))
    except Exception:
        krb_traceback.print_exc()
        sys.exit(1)


    try:
        with engine.prove_goal(
               'weather_rules.what_to_bring_more($bring)') \
          as gen:
            for vars, plan in gen:
                print("You should bring also: %s" % (vars['bring']))
    except Exception:
        krb_traceback.print_exc()
        sys.exit(1)

weather_test()

