This is an experimental Computer Based Training (CBT) program to teach the
user Pyke.

(Currently, it only teaches patterns and pattern matching).

This uses question bases.  Even though the example is rather rough and
incomplete it is left here as an example of question bases...

To run this:

    $ python
    >>> import driver
    >>> driver.run()

